package delivery;

public enum UserType { Customer, RestaurantOwner, DeliveryPerson };
